import React, { useState, useEffect, useCallback } from 'react';
import {
  AppProvider,
  Page,
  Layout,
  Card,
  ResourceList,
  ResourceItem,
  Text,
  Thumbnail,
  Button,
  TextField,
  BlockStack,
  InlineStack,
  Banner,
  Spinner,
  Badge,
  EmptyState,
  Box,
  Divider,
  Icon,
  Tabs,
  Frame,
  Toast
} from '@shopify/polaris';
import { ImageIcon, AlertCircleIcon, SearchIcon, CheckIcon, SaveIcon, ExitIcon } from '@shopify/polaris-icons';
import '@shopify/polaris/build/esm/styles.css';
import frTranslations from '@shopify/polaris/locales/fr.json';

// Types based on our backend response
interface ProductImage {
  id: string;
  url: string;
}

interface ProductVariant {
  id: string;
  title: string;
  assignedImages: string[];
}

interface Product {
  id: string;
  title: string;
  thumbnail: string | null;
  images: ProductImage[];
  variants: ProductVariant[];
}

export default function App() {
  return (
    <AppProvider i18n={frTranslations}>
      <Frame>
        <MainApp />
      </Frame>
    </AppProvider>
  );
}

function MainApp() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingStep, setLoadingStep] = useState('Initialisation...');
  const [error, setError] = useState<string | null>(null);
  const [shopDomain, setShopDomain] = useState<string>('');

  const [activeTab, setActiveTab] = useState(0);
  const [isInstallingTheme, setIsInstallingTheme] = useState(false);
  const [themeInstallMessage, setThemeInstallMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<string | null>(null);
  
  // State to hold which images belong to which variant (local edits before save)
  const [assignments, setAssignments] = useState<Record<string, string[]>>({});
  
  const [isSaving, setIsSaving] = useState(false);
  const [showSavedToast, setShowSavedToast] = useState(false);
  const toggleToast = useCallback(() => setShowSavedToast((active) => !active), []);

  const [rawDebugData, setRawDebugData] = useState<any>(null);

  // Helper for API headers
  const getAuthHeaders = () => {
    const token = localStorage.getItem('shopify_token');
    const shop = localStorage.getItem('shopify_shop');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token && shop) {
      headers['x-shopify-token'] = token;
      headers['x-shopify-shop'] = shop;
    }
    return headers;
  };

  const fetchProducts = async () => {
    setIsLoading(true);
    setLoadingStep('Préparation de la requête...');
    setError(null);
    setRawDebugData(null);
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    
    try {
      setLoadingStep('Vérification de la boutique...');
      const shopRes = await fetch('/api/shop', { 
        headers: getAuthHeaders(),
        signal: controller.signal 
      }).catch(() => null);
      
      if (shopRes && shopRes.ok) {
        const shopData = await shopRes.json().catch(() => ({}));
        if (shopData.domain) setShopDomain(shopData.domain);
      }

      setLoadingStep('Récupération des produits depuis Shopify...');
      const res = await fetch('/api/products', { 
        headers: getAuthHeaders(),
        signal: controller.signal 
      });
      
      setLoadingStep('Analyse de la réponse...');
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('text/html')) {
        throw new Error("L'API a retourné une page HTML au lieu de données JSON.");
      }
      
      const data = await res.json();
      
      if (!res.ok) {
        if (data.error === 'MISSING_CREDENTIALS' || data.error === 'Veuillez connecter votre boutique Shopify.') {
          localStorage.removeItem('shopify_token');
          localStorage.removeItem('shopify_shop');
          throw new Error('Veuillez connecter votre boutique Shopify pour continuer.');
        }
        throw new Error(data.error || 'Erreur lors du chargement des produits');
      }
      
      setLoadingStep("Préparation de l'affichage...");
      setProducts(data.products || []);
      
      if (data.shopInfo && data.shopInfo.name) {
        setShopDomain(`${data.shopInfo.name} (${data.shopInfo.myshopifyDomain})`);
      }
      
      if (!data.products || data.products.length === 0) {
        setRawDebugData(data);
      }

      const initialAssignments: Record<string, string[]> = {};
      if (data.products) {
        data.products.forEach((p: Product) => {
          p.variants.forEach(v => {
            initialAssignments[v.id] = v.assignedImages || [];
          });
        });
      }
      setAssignments(initialAssignments);
      
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setError("La connexion au serveur a expiré (timeout).");
      } else {
        setError(err.message || "Une erreur inconnue s'est produite");
      }
    } finally {
      clearTimeout(timeoutId);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get('token');
    const urlShop = params.get('shop');

    if (urlToken && urlShop) {
      localStorage.setItem('shopify_token', urlToken);
      localStorage.setItem('shopify_shop', urlShop);
      window.history.replaceState({}, document.title, '/');
    }

    const token = localStorage.getItem('shopify_token');
    if (!token) {
      setIsLoading(false);
      setError('Veuillez connecter votre boutique Shopify pour continuer.');
      return;
    }

    fetchProducts();
  }, []);

  const filteredProducts = (products || []).filter(p => 
    (p.title || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedProduct = products.find(p => p.id === selectedProductId);

  const handleSelectProduct = (productId: string) => {
    setSelectedProductId(productId);
    const product = products.find(p => p.id === productId);
    if (product && product.variants && product.variants.length > 0) {
      setSelectedVariantId(product.variants[0].id);
    } else {
      setSelectedVariantId(null);
    }
  };

  const handleBackToProducts = () => {
    setSelectedProductId(null);
    setSelectedVariantId(null);
  };

  const handleToggleImage = (imageId: string) => {
    if (!selectedVariantId) return;

    setAssignments(prev => {
      const currentVariantImages = prev[selectedVariantId] || [];
      const isCurrentlyAssigned = currentVariantImages.includes(imageId);
      
      let newVariantImages;
      if (isCurrentlyAssigned) {
        newVariantImages = currentVariantImages.filter(id => id !== imageId);
      } else {
        newVariantImages = [...currentVariantImages, imageId];
      }

      return {
        ...prev,
        [selectedVariantId]: newVariantImages
      };
    });
  };

  const handleThemeInstall = async () => {
    setIsInstallingTheme(true);
    setThemeInstallMessage(null);
    try {
      const res = await fetch('/api/theme/install', { 
        method: 'POST',
        headers: getAuthHeaders()
      });
      
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('text/html')) {
        throw new Error("Erreur serveur : L'API a retourné une page HTML.");
      }
      
      const data = await res.json();
      if (!res.ok) {
        if (data.error === 'MISSING_CREDENTIALS') {
          throw new Error('Veuillez connecter votre boutique Shopify.');
        }
        throw new Error(data.error || "Erreur d'installation");
      }
      setThemeInstallMessage({ type: 'success', text: data.message });
    } catch (err: any) {
      setThemeInstallMessage({ type: 'error', text: err.message });
    } finally {
      setIsInstallingTheme(false);
    }
  };

  const openThemeEditor = () => {
    if (shopDomain) {
      window.open(`https://${shopDomain}/admin/themes/current/editor?context=apps`, '_blank');
    }
  };

  const handleSave = async () => {
    if (!selectedVariantId) return;
    
    setIsSaving(true);
    try {
      const imageIdsToSave = assignments[selectedVariantId] || [];
      
      const res = await fetch('/api/variants/images', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          variantId: selectedVariantId,
          imageIds: imageIdsToSave
        })
      });

      const data = await res.json();
      if (!res.ok) {
        if (data.error === 'MISSING_CREDENTIALS') {
          throw new Error('Veuillez connecter votre boutique Shopify.');
        }
        throw new Error(data.error || 'Erreur lors de la sauvegarde');
      }

      setShowSavedToast(true);
    } catch (err: any) {
      alert(`Erreur: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const [shopUrlInput, setShopUrlInput] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('shop') || '';
  });
  const [isConnecting, setIsConnecting] = useState(false);
  const [authUrl, setAuthUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!shopUrlInput || shopUrlInput.length < 5) {
      setAuthUrl(null);
      return;
    }
    
    const fetchUrl = async () => {
      try {
        const res = await fetch(`/api/auth/url?shop=${encodeURIComponent(shopUrlInput)}&t=${Date.now()}`);
        if (res.ok) {
          const data = await res.json();
          setAuthUrl(data.url);
        }
      } catch (e) {
        // Ignore pre-fetch errors
      }
    };
    
    const timeout = setTimeout(fetchUrl, 500);
    return () => clearTimeout(timeout);
  }, [shopUrlInput]);

  const handleConnect = async () => {
    if (!shopUrlInput) return;
    
    setIsConnecting(true);
    setError(null);
    
    try {
      let finalAuthUrl = authUrl;
      
      if (!finalAuthUrl) {
        const res = await fetch(`/api/auth/url?shop=${encodeURIComponent(shopUrlInput)}&t=${Date.now()}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Erreur de connexion');
        finalAuthUrl = data.url;
      }
      
      window.top!.location.href = finalAuthUrl;
      
    } catch (err: any) {
      setError(err.message);
      setIsConnecting(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('shopify_token');
    localStorage.removeItem('shopify_shop');
    window.location.reload();
  };

  if (isLoading) {
    return (
      <Page>
        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack align="center" inlineAlign="center" gap="400">
                <Box padding="800">
                  <BlockStack align="center" inlineAlign="center" gap="400">
                    <Spinner size="large" />
                    <Text as="h2" variant="headingMd">Connexion à Shopify et chargement des produits...</Text>
                    <Text as="p" tone="subdued">{loadingStep}</Text>
                    <Box paddingBlockStart="400">
                      <Button variant="plain" onClick={() => {
                        localStorage.removeItem('shopify_token');
                        localStorage.removeItem('shopify_shop');
                        setError('Veuillez connecter votre boutique Shopify pour continuer.');
                        setIsLoading(false);
                      }}>
                        Forcer la reconnexion à Shopify
                      </Button>
                    </Box>
                  </BlockStack>
                </Box>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  if (error && !localStorage.getItem('shopify_token')) {
    return (
      <Page>
        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <BlockStack align="center" inlineAlign="center" gap="200">
                  <Icon source={ImageIcon} tone="base" />
                  <Text as="h1" variant="headingLg">Variant Images Manager</Text>
                  <Text as="p" tone="subdued">Connectez votre boutique Shopify pour commencer à gérer les images de vos variantes.</Text>
                </BlockStack>
                
                <Box paddingBlockStart="400">
                  <BlockStack gap="400">
                    <TextField
                      label="URL de votre boutique"
                      value={shopUrlInput}
                      onChange={setShopUrlInput}
                      placeholder="ma-boutique.myshopify.com"
                      autoComplete="off"
                      helpText="Entrez l'URL en .myshopify.com de votre boutique."
                    />
                    
                    {error && error !== 'Veuillez connecter votre boutique Shopify pour continuer.' && error !== 'Veuillez connecter votre boutique Shopify.' && (
                      <Banner tone="critical">
                        <p>{error}</p>
                      </Banner>
                    )}

                    <Button 
                      variant="primary" 
                      onClick={handleConnect} 
                      loading={isConnecting} 
                      disabled={!shopUrlInput}
                    >
                      Connecter la boutique
                    </Button>
                  </BlockStack>
                </Box>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      </Page>
    );
  }

  const tabs = [
    {
      id: 'products',
      content: 'Produits',
      accessibilityLabel: 'Produits',
      panelID: 'products-panel',
    },
    {
      id: 'theme',
      content: 'Intégration au Thème',
      panelID: 'theme-panel',
    },
  ];

  return (
    <Page
      title={activeTab === 1 ? 'Intégration au Thème' : (selectedProduct ? selectedProduct.title : 'Gestionnaire d\'Images par Variante')}
      backAction={selectedProductId && activeTab === 0 ? { content: 'Retour', onAction: handleBackToProducts } : undefined}
      primaryAction={selectedProductId && activeTab === 0 ? {
        content: 'Enregistrer la variante',
        onAction: handleSave,
        loading: isSaving,
        icon: SaveIcon
      } : undefined}
      secondaryActions={[
        {
          content: 'Déconnexion',
          icon: ExitIcon,
          onAction: handleLogout,
          destructive: true
        }
      ]}
    >
      <Box paddingBlockEnd="400">
        <Tabs tabs={tabs} selected={activeTab} onSelect={setActiveTab} />
      </Box>

      {activeTab === 1 ? (
        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Afficher les images sur votre boutique</Text>
                <Text as="p" tone="subdued">
                  Pour que seules les images sélectionnées s'affichent lorsqu'un client choisit une variante, 
                  vous devez autoriser l'application à modifier l'affichage de votre thème.
                </Text>

                <Divider />

                <BlockStack gap="400">
                  <Text as="h3" variant="headingMd">Option 1 : Activer via l'Éditeur de Thème (Recommandé)</Text>
                  <Text as="p" tone="subdued">
                    Ouvrez l'éditeur de thème Shopify et activez l'intégration de l'application dans les paramètres d'intégration (App Embeds).
                  </Text>
                  <InlineStack>
                    <Button onClick={openThemeEditor}>Ouvrir l'éditeur de thème</Button>
                  </InlineStack>
                </BlockStack>

                <Divider />

                <BlockStack gap="400">
                  <Text as="h3" variant="headingMd">Option 2 : Installation Automatique</Text>
                  <Text as="p" tone="subdued">
                    L'application va injecter automatiquement le code nécessaire dans votre thème principal. 
                    Aucune action manuelle n'est requise.
                  </Text>
                  
                  {themeInstallMessage && (
                    <Banner tone={themeInstallMessage.type === 'success' ? 'success' : 'critical'}>
                      <p>{themeInstallMessage.text}</p>
                    </Banner>
                  )}

                  <InlineStack>
                    <Button onClick={handleThemeInstall} loading={isInstallingTheme} variant="primary">
                      Installer automatiquement
                    </Button>
                  </InlineStack>
                </BlockStack>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      ) : !selectedProductId ? (
        <Layout>
          <Layout.Section>
            <Card padding="0">
              <Box padding="400">
                <TextField
                  label="Rechercher des produits"
                  labelHidden
                  value={searchQuery}
                  onChange={setSearchQuery}
                  prefix={<Icon source={SearchIcon} />}
                  placeholder="Rechercher des produits..."
                  autoComplete="off"
                  clearButton
                  onClearButtonClick={() => setSearchQuery('')}
                />
              </Box>
              
              {filteredProducts.length > 0 ? (
                <ResourceList
                  resourceName={{ singular: 'produit', plural: 'produits' }}
                  items={filteredProducts}
                  renderItem={(product) => {
                    const media = <Thumbnail
                      source={product.thumbnail || ImageIcon}
                      alt={product.title}
                    />;

                    return (
                      <ResourceItem
                        id={product.id}
                        url="#"
                        media={media}
                        onClick={() => handleSelectProduct(product.id)}
                      >
                        <InlineStack align="space-between" blockAlign="center">
                          <Text variant="bodyMd" fontWeight="bold" as="h3">
                            {product.title}
                          </Text>
                          <Badge>{product.variants?.length || 0} variantes</Badge>
                        </InlineStack>
                      </ResourceItem>
                    );
                  }}
                />
              ) : (
                <EmptyState
                  heading="Aucun produit trouvé"
                  image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                >
                  <p>Si vous avez des produits sur votre boutique, assurez-vous de vous être connecté avec la bonne URL de boutique.</p>
                </EmptyState>
              )}
            </Card>
          </Layout.Section>
        </Layout>
      ) : (
        <Layout>
          <Layout.Section variant="oneThird">
            <Card padding="0">
              <Box padding="400" borderBlockEndWidth="025" borderColor="border">
                <Text as="h2" variant="headingSm">Sélectionnez une variante</Text>
              </Box>
              <ResourceList
                resourceName={{ singular: 'variante', plural: 'variantes' }}
                items={selectedProduct?.variants || []}
                renderItem={(variant) => {
                  const isSelected = selectedVariantId === variant.id;
                  const assignedCount = (assignments[variant.id] || []).length;
                  
                  return (
                    <ResourceItem
                      id={variant.id}
                      url="#"
                      onClick={() => setSelectedVariantId(variant.id)}
                    >
                      <InlineStack align="space-between" blockAlign="center">
                        <Text variant="bodyMd" fontWeight={isSelected ? 'bold' : 'regular'} as="span">
                          {variant.title}
                        </Text>
                        {assignedCount > 0 && (
                          <Badge tone="info">{assignedCount} image{assignedCount > 1 ? 's' : ''}</Badge>
                        )}
                      </InlineStack>
                    </ResourceItem>
                  );
                }}
              />
            </Card>
            <Box paddingBlockStart="400">
              <Banner tone="info" icon={AlertCircleIcon}>
                <p>
                  Les images sélectionnées ici seront enregistrées dans un <strong>Metafield Shopify</strong>. Vous devrez ajouter un petit bout de code dans votre thème pour les filtrer sur la boutique.
                </p>
              </Banner>
            </Box>
          </Layout.Section>

          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <BlockStack gap="200">
                  <Text as="h2" variant="headingMd">Assignez les images</Text>
                  <Text as="p" tone="subdued">
                    Cliquez sur les images du produit pour les lier à la variante sélectionnée (<strong>{selectedProduct?.variants?.find(v => v.id === selectedVariantId)?.title}</strong>). N'oubliez pas d'enregistrer.
                  </Text>
                </BlockStack>

                {(!selectedProduct?.images || selectedProduct.images.length === 0) ? (
                  <EmptyState
                    heading="Ce produit n'a aucune image"
                    image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                  >
                    <p>Ajoutez d'abord des images dans Shopify.</p>
                  </EmptyState>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '16px' }}>
                    {selectedProduct.images.map(image => {
                      const isAssigned = selectedVariantId ? (assignments[selectedVariantId] || []).includes(image.id) : false;
                      
                      return (
                        <div 
                          key={image.id}
                          onClick={() => handleToggleImage(image.id)}
                          style={{
                            position: 'relative',
                            aspectRatio: '1/1',
                            borderRadius: '8px',
                            overflow: 'hidden',
                            cursor: 'pointer',
                            border: isAssigned ? '2px solid #008060' : '1px solid #e1e3e5',
                            boxShadow: isAssigned ? '0 0 0 1px rgba(0, 128, 96, 0.5)' : 'none',
                            transition: 'all 0.2s ease'
                          }}
                        >
                          <img 
                            src={image.url} 
                            alt="Product" 
                            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                            referrerPolicy="no-referrer"
                          />
                          
                          <div style={{
                            position: 'absolute',
                            top: '8px',
                            right: '8px',
                            width: '24px',
                            height: '24px',
                            borderRadius: '4px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            backgroundColor: isAssigned ? '#008060' : 'white',
                            border: isAssigned ? 'none' : '1px solid #c9cccf',
                            color: isAssigned ? 'white' : 'transparent',
                            transition: 'all 0.2s ease'
                          }}>
                            <Icon source={CheckIcon} tone={isAssigned ? 'textInverse' : 'base'} />
                          </div>
                          
                          {!isAssigned && (
                            <div style={{
                              position: 'absolute',
                              inset: 0,
                              backgroundColor: 'rgba(0,0,0,0.05)',
                              transition: 'background-color 0.2s ease'
                            }} />
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      )}

      {showSavedToast && (
        <Toast content="Images enregistrées dans Shopify !" onDismiss={toggleToast} />
      )}
    </Page>
  );
}
